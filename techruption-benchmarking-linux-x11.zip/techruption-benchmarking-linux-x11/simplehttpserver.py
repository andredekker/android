import asyncio
from aiohttp import web
import time
import os

# https://aiohttp.readthedocs.io/en/stable/web_lowlevel.html

allowed_downloads = [
    '/0/public-cipher/public-cipher.p',
    '/0/decrypted/decrypted.p',
    '/1/public-cipher/public-cipher.p',
    '/1/decrypted/decrypted.p',
    '/2/public-cipher/public-cipher.p',
    '/2/decrypted/decrypted.p',
    '/3/public-cipher/public-cipher.p',
    '/3/decrypted/decrypted.p'
]


async def handler(request):
    print(request.remote, 'requested',  request.raw_path)
    if request.method == 'GET' and request.raw_path in allowed_downloads:
        return web.FileResponse(await get_file('.'+request.raw_path))
    else:
        return web.Response(text="Connection working\n")


async def get_file(path):
    while not os.path.isfile(path):
        await asyncio.sleep(.1)
    return path


async def main():
    server = web.Server(handler)
    runner = web.ServerRunner(server)
    await runner.setup()
    site = web.TCPSite(runner, 'simplehttpserver', 80)
    await site.start()

    print("======= Serving on http://simplehttpserver:80/ ======")

    # pause here for very long time by serving HTTP requests and
    # waiting for keyboard interruption
    await asyncio.sleep(100*3600)


loop = asyncio.get_event_loop()

try:
    loop.run_until_complete(main())
except KeyboardInterrupt:
    pass
loop.close()
