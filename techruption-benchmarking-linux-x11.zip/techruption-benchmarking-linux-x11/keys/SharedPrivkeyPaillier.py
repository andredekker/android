from phe import paillier
from math import gcd
from phe.util import invert, powmod

import random

def generate_shared_paillier_keypair(key_length=None,nparty=1):
    '''First generate a single paillier key-pair.
     The private key is (additively) secret shared amongst the players.
     The current implementation stores everyting in a single object,
     in practice this is not secure of course.
     This is a simplified version of the threshold scheme of Damgard-Jurik 2001,
     who use Shamir secret sharing and the Paillier generalization.

     To-do:
      - Check that the partial decryption result do not contain any information about the plaintexts. Marybe rerandomization is required.
      - The PHE library optimized decryption by using the Chinese Remainder Theorem. Is this also possible in this case?
      - Instead of additive secret sharing we might use Shamir. Hence use the DJ01 protocol and obtain a threshold scheme.
     '''

    pubkey,privkey = paillier.generate_paillier_keypair(None, key_length)

    shared_private_key = PaillierSharedPrivateKey(pubkey,privkey,Players=nparty)
    return pubkey,privkey,shared_private_key

class PaillierSharedPrivateKey(object):

    def __init__(self, public_key, private_key,Players=1):
        p = private_key.p
        q = private_key.q
        if not p * q == public_key.n:
            raise ValueError('given public key does not match the given p and q.')
        if p == q:  # check that p and q are different, otherwise we can't compute p^-1 mod q
            raise ValueError('p and q have to be different')
        self.public_key = public_key

        Lambda = (p-1)*(q-1)//gcd(p-1,q-1)
        LambdaInverse = invert(Lambda,self.public_key.n)
        d_tot = LambdaInverse * Lambda

        d=[random.SystemRandom().randrange(1, Lambda*public_key.n) for i in range(Players-1)]
        d.append((d_tot-sum(d)%(Lambda*public_key.n)))
        self.d=d

    @staticmethod
    def __repr__(self):
        pub_repr = repr(self.public_key)
        return "<PaillierSharedPrivateKey for {}>".format(pub_repr)

    def decrypt(self, encrypted_number):
        """Return the decrypted & decoded plaintext of *encrypted_number*.

        Uses the default :class:`EncodedNumber`, if using an alternative encoding
        scheme, use :meth:`decrypt_encoded` or :meth:`raw_decrypt` instead.

        Args:
          encrypted_number (EncryptedNumber): an
            :class:`EncryptedNumber` with a public key that matches this
            private key.

        Returns:
          the int or float that `EncryptedNumber` was holding. N.B. if
            the number returned is an integer, it will not be of type
            float.

        Raises:
          TypeError: If *encrypted_number* is not an
            :class:`EncryptedNumber`.
          ValueError: If *encrypted_number* was encrypted against a
            different key.
        """
        encoded = self.decrypt_encoded(encrypted_number)
        return encoded.decode()

    def decrypt_encoded(self, encrypted_number, Encoding=None):
        """Return the :class:`EncodedNumber` decrypted from *encrypted_number*.

        Args:
          encrypted_number (EncryptedNumber): an
            :class:`EncryptedNumber` with a public key that matches this
            private key.
          Encoding (class): A class to use instead of :class:`EncodedNumber`, the
            encoding used for the *encrypted_number* - used to support alternative
            encodings.

        Returns:
          :class:`EncodedNumber`: The decrypted plaintext.

        Raises:
          TypeError: If *encrypted_number* is not an
            :class:`EncryptedNumber`.
          ValueError: If *encrypted_number* was encrypted against a
            different key.
        """
        if not isinstance(encrypted_number, paillier.EncryptedNumber):
            raise TypeError('Expected encrypted_number to be an EncryptedNumber'
                            ' not: %s' % type(encrypted_number))

        if self.public_key != encrypted_number.public_key:
            raise ValueError('encrypted_number was encrypted against a '
                             'different key!')

        if Encoding is None:
            Encoding = paillier.EncodedNumber

        partial_decrypt=self.partial_decrypt(encrypted_number)

        encoded = self.combine_decryptions(partial_decrypt)
        return Encoding(self.public_key, encoded,
                        encrypted_number.exponent)

    def combine_decryptions(self, part_decrypt):
        """Combine partial decryptions of a ciphertext and return raw plaintext.

        Args:
          ciphertext (list of int):
            Partial decryptions that are to be combined

        Returns:
          int: Paillier decryption of ciphertext. This is a positive
          integer < :attr:`public_key.n`.

        Raises:
          TypeError: if ciphertext is not an int.
        """
        if not all(isinstance(item, int) for item in part_decrypt):
            raise TypeError('Expected ciphertext to be a list of int, not: %s' %
                            type(part_decrypt))

        # Combine all partial decryptions by multiplying them.
        combine_decrypt=part_decrypt[0];
        for i in range(len(part_decrypt)-1):
            combine_decrypt=combine_decrypt*part_decrypt[i+1]%(self.public_key.n**2)

        # Run the final step of the decryption algorithm.
        decrypt = self.l_function(combine_decrypt, self.public_key.n) % self.public_key.n
        return decrypt

    def partial_decrypt(self,encrypted_number):
        '''Runs all partial decryptions, i.e. doing the modular exponentiation with all the private key shares.
        The be_secure=False option (not the default) ensures that the ciphertext is NOT obfuscated (rerandomized) when
        retrieved. When sharing ciphertexts with other parties obfuscation is crucial. However, if  we obfuscate in this scenario
        the players will do partial decryptions on different ciphertexts and the combination does not make sense anymore.
        '''

        part_decrypt = [powmod(encrypted_number.ciphertext(be_secure=False), self.d[i], self.public_key.n ** 2) for i in range(len(self.d))]
        return part_decrypt

    def l_function(self, x, p):
        """Computes the L function as defined in Paillier's paper. That is: L(x,p) = (x-1)/p"""
        return (x - 1) // p


if __name__ == "__main__":
    pubkey,privkey,shared_private_key = generate_shared_paillier_keypair(2**12)

    c = pubkey.encrypt(107120)
    m = shared_private_key.decrypt(c)
    print(m)

