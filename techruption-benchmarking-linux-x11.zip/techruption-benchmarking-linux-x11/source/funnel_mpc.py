import ConfigTool
import CsvTool
import IoTool
import HttpTool
import funnelplot

import asyncio
from phe import paillier
import time
import math

def secure_sum(config):
    '''
    Simple circuit computing encryption of the sum of 3 values,
    from the encryptions of these values.
    Raises overflow errors
    '''
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(HttpTool.fetch_public_ciphers(config))
    loop.run_until_complete(future)

    ciphers, players = future.result()
    return sum(ciphers)

def shared_decryption(encrypted_sum, privkey, config):
    '''
    Distributed decryption protocol.
    First all parties locally perform partial decryption, and write result in public directory.
    Then, they combine the decrypted values to obtain the plain text.
    '''
    # x = read_file(out_enc)
    x_decr_part = privkey.partial_decrypt(encrypted_sum)
    IoTool.write_file(config.partial_decryption_filename, x_decr_part)
    time.sleep(6)

    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(HttpTool.fetch_shared_decryption(config))
    loop.run_until_complete(future)

    x_decr = [x for x in future.result()]

    x_comb = privkey.combine_decryptions(x_decr)
    return x_comb


# Main program
def main():
    # Read program configuration from file
    config = ConfigTool.get_config("config.json")
    # Read our pre-made keys from the given files
    pubkey = IoTool.read_file(config.public_key_filename)
    privkey = IoTool.read_file(config.private_key_filename)
    print("MPC Benchmarking demo initialised. This is party {}.".format(config.party_id))

    # Read data from the CSV and compute our stats
    csv = CsvTool.get_csv("data.csv")
    count_total = len(csv)
    count_kpi = CsvTool.csv_count(csv, config.kpi_column)
    print("Found {} patients, {} of which had a second referral".format(count_total, count_kpi))

    # We now have our input data. Time to compute the secure sum and decrypt it with the others.
    # Two passes: first, we share/compute the total of the KPI columns
    print("MPC First pass: secure sum of patients with referral ...")
    IoTool.write_file(config.shared_secret_filename, pubkey.encrypt(count_kpi))
    time.sleep(6)
    encrypted_sum = secure_sum(config)
    total_kpi = shared_decryption(encrypted_sum, privkey, config)
    print("  ... complete. Sum is {}".format(total_kpi))
    # Two passes: second, we share/compute the total number of patients
    print("MPC Second pass: secure sum of all patients ...")
    IoTool.write_file(config.shared_secret_filename, pubkey.encrypt(count_total))
    time.sleep(6)
    encrypted_sum = secure_sum(config)
    total_entries = shared_decryption(encrypted_sum, privkey, config)
    print("  ... complete. Sum is {}".format(total_entries))

    weighted_average = total_kpi / total_entries

    # Funnel plot time. The plot requires axis limits for the x-axis (count_total)
    # but of course we do not know the correct value for this, since we don't know
    # the maximum value of count_total between all parties.
    # Approximate it by assuming that count_total never exceeds (sum count_total)/
    # sqrt(2), but also ensure that the own data point is well within the plot.
    plot_xmax = max(total_entries / math.sqrt(2), count_total * math.sqrt(2))

    print("Weighted average is {}. Displaying funnel plot.".format(weighted_average))
    funnelplot.main(weighted_average, plot_xmax, data={
        'population_size': count_total,
        'referral_size': count_kpi
    })

if __name__ == "__main__":
    main()
