import json

# Imports configuration file and loads it as an object.
# The configuration file is expected to be in json format, and
# to contain the keys given below as defaults.
# Any missing values are replaced by the defaults.
# Any inconsistencies (e.g. party_id > number_of_parties) are
# used as given, so check your input.

DEFAULT_VALUES = {
    "kpi_column": "kpi", # csv column name
    "party_id": "0", # one of [0..n)
    "number_of_parties": "4", # n
    "ip_addresses": [
        "0.0.0.0", 
        "0.0.0.0", 
        "0.0.0.0", 
        "0.0.0.0"], # IP's of all n players
    "shared_secret_filename": "/public-cipher/public-cipher.p",
    "partial_decryption_filename": "/decrypted/decrypted.p",
    "public_key_filename": "/pubkey",
    "private_key_filename": "/privkey"
}

# The object that will contain config values.
# Constructed using a json string; any missing values are replaced
# by defaults 
class Config:
    def __init__(self, data):
        # Get the data, and add any missing keys using default value
        configuration = json.loads(data)
        for k in DEFAULT_VALUES:
            if k not in configuration:
                configuration[k] = DEFAULT_VALUES[k]
        # Allow access as self.key == value
        self.__dict__ = configuration

# Initialize a config object from a json file
def get_config(filename):
    return Config(open(filename).read())
