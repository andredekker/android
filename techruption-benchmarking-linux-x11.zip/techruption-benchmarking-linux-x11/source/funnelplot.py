import numpy as np
import matplotlib.pyplot as plt

NUM_STEPS = 30
NUM_STD = 3
DEFAULT_DATA = {'population_size': 0, 'referral_size': 0}


def compute_confidence_intervals(p, max_samples, num_steps=NUM_STEPS,
                                 num_std=NUM_STD):
    """Computes the confidence intervals based on the average and a number of
    standard deviations. Note that the current (Normal) approximation is only
    justified for large n and p (rule-of-thumb: n >= 15, p >= 0.1). Additional
    approximations should be implemented for smaller samples.
    """

    # Compute standard deviation for single sample experiment
    std = p * (1 - p)

    # Standard deviation for experiment of various sample sizes
    std_samplesize = np.sqrt(std / np.linspace(1, max_samples,
                                               num=num_steps,
                                               dtype=int))

    # Confidence intervals (num_std standard deviations) around average value
    conf_int_lower = p - num_std * std_samplesize
    conf_int_upper = p + num_std * std_samplesize

    # Clip confidence intervals between 0 and 1
    conf_int_lower = conf_int_lower.clip(min=0)
    conf_int_upper = conf_int_upper.clip(max=1)
    return conf_int_lower, conf_int_upper


def make_funnel_plot(avg, max_samples, num_steps=NUM_STEPS, num_std=NUM_STD):
    """Create figure and add average and confidence intervals."""
    x = np.linspace(1, max_samples, num=num_steps, dtype=int)
    y = np.full(shape=x.shape, fill_value=avg)
    conf_int_lower, conf_int_upper = compute_confidence_intervals(avg,
                                                                  max_samples,
                                                                  num_steps,
                                                                  num_std)
    fig, ax = plt.subplots()
    ax.plot(x, y, 'k-', label='Average')
    ax.plot(x, conf_int_lower, 'k-.',
            label=f'Confidence interval ({num_std} STDs)')
    ax.plot(x, conf_int_upper, 'k-.')
    ax.set_xlim([0, x[-1]])
    ax.set_ylim([0, conf_int_upper[1]])
    return fig, ax


def add_local_data_to_plot(data, funnel_ax):
    """Add local data of the party to the funnel plot for easy
    visual benchmarking.
    """
    assert data.keys() == {'population_size', 'referral_size'}
    assert isinstance(data['population_size'], int) or \
           data['population_size'] is None
    assert isinstance(data['referral_size'], int) or \
           data['referral_size'] is None
    assert 0 <= data['referral_size'] <= data['population_size']

    if data['population_size'] == 0:
        return

    ratio = data['referral_size'] / data['population_size']
    funnel_ax.plot(data['population_size'], ratio, 'r.', markersize=20,
                   label='Your organisation')
    xlims = list(funnel_ax.get_xlim())
    xlims[1] = max(xlims[1], data['referral_size'])
    funnel_ax.set_xlim(xlims)

    ylims = list(funnel_ax.get_ylim())
    ylims[1] = max(ylims[1], ratio)
    funnel_ax.set_ylim(ylims)


def main(avg, max_samples, data=None, num_steps=NUM_STEPS,
         num_std=NUM_STD):
    assert 0 <= avg <= 1
    assert max_samples > 0
    if data is None:
        data = DEFAULT_DATA
    print(f"Average equals {avg}")

    # Make funnel plot
    funnel_fig, funnel_ax = make_funnel_plot(avg, max_samples, num_steps,
                                             num_std)

    # Add points to funnel plot
    add_local_data_to_plot(data, funnel_ax)

    # Show plot
    plt.figure(funnel_fig.number)
    funnel_ax.legend()
    plt.show()


if __name__ == "__main__":
    main(avg=.1, max_samples=4000, data={'population_size': 2500,
                                         'referral_size': 300})
