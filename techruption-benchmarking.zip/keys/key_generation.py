import os
import pickle
import SharedPrivkeyPaillier
import argparse
import copy

KEY_LENGTH = 2 ** 11
KAPPA = 40
PUB_SUBDIRS = ['number_of_nodes','nondangling','pre_mult','decryption','division','results']

def parse(inp=None):
    parser = argparse.ArgumentParser(description='Make Shared Paillier Keys for Secure PageRank')
    parser.add_argument('--nparty', type=int, metavar=3, default=0,
                        help='Number of parties.')
    parser.add_argument('--pubdir', metavar='directory', default=None,
                        help='Automatically generate directories for each party.')
    parser.add_argument('--privdirs', metavar='directories', default=None, nargs='+',
                        help='Automatically generate directories for each party.')
    args = parser.parse_args(inp)

    if len(args.privdirs) != args.nparty:
        raise ValueError('Argument "nparty" should equal the number of "privdirs" arguments.')

    runpath = os.getcwd()
    args.pubdir = (runpath + "/" + args.pubdir if args.pubdir[0] != '/' else args.pubdir)
    args.pubdir = (args.pubdir if not args.pubdir.endswith('/') else args.pubdir[:-1])

    privdirs = args.privdirs
    args.privdirs = []
    for privdir in privdirs:
        temp = (runpath + "/" + privdir if privdir[0] != '/' else privdir)
        temp = (temp if temp[-1] != '/' else temp[:-1])
        args.privdirs.append(temp)

    # dummy = create_dirs(args.pubdir, args.privdirs)

    return args

def create_dirs(public_dir, privdirs):

    # Create public key directory if it does not exist
    try:
        os.mkdir(public_dir)
    except:
        pass

    # Create public subdirectories if it does not exist
    for subdir in PUB_SUBDIRS:
        try:
            os.mkdir(public_dir + '/' + subdir)
        except:
            pass

    # Create private key directories if they do no not exist
    for privdir in privdirs:
        try:
            os.mkdir(privdir)
        except:
            pass

    return('success')

def new_keypair(key_length, nparty):

    (pubkey, privkey, shared_privkey) = SharedPrivkeyPaillier.generate_shared_paillier_keypair(key_length, nparty)
    return (pubkey, shared_privkey)

def new_keypair_shared(key_length, pubdir, privdirs, nparty):

    if nparty != len(privdirs): return('Something went wrong.')

    (pubkey, privkeys) = new_keypair(key_length, nparty)

    # assuming N>=2**2047 and \kappa=40, we get | N / (2(1+2**\kappa)) | \approx 2**2005
    pubkey.max_int = 2 ** (KEY_LENGTH - KAPPA - 3) - 1

    with open(pubdir + '/pubkey', 'wb') as f:
        pickle.dump(pubkey, f)

    for i in range(nparty):
        privdir = privdirs[i]
        privkey = copy.deepcopy(privkeys)
        privkey.d = [privkey.d[i]]
        # assuming N>=2**2047 and \kappa=40, we get | N / (2(1+2**\kappa)) | \approx 2**2005
        privkey.public_key.max_int = 2 ** ( KEY_LENGTH - KAPPA - 3) - 1
        with open(privdir + '/privkey' + str(i), 'wb') as f:
            pickle.dump(privkey, f)

    return('Key generation finished.')

if __name__ == "__main__":

    args = parse()
    message = new_keypair_shared(KEY_LENGTH, args.pubdir, args.privdirs, args.nparty)
    print(message)
