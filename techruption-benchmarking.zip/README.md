# MPC Funnel plot demo

This is a quick demonstration of how MPC might be used for benchmarking.

We take the case of hospitals wishing to benchmark their treatment of patients.
They each have a list of patients treated, and whether these patients had to come back for a second round of treatment.
They wish to compare their proportion of 'referral' patients with those of other hospitals, without sharing their proportion.

The demo takes the four data files, and simulates four hospitals interacting in a "secure average" benchmark, computing the weighted average of their proportion of referral patients (weighed by number of patients).
A 'funnel plot' is displayed for each hospital; these are identical, but each hospital sees their own data point in the graph.

## Prerequisites

Clone the repository and install [Docker and Docker Compose](https://hub.docker.com/search/?type=edition&offering=community).
In addition, you require an X server in order to view the plots.
For Windows, [VcXsrv](https://sourceforge.net/projects/vcxsrv/) is recommended.

## Running the demo

1. Build the common Python image by running the following command (in the repository root), replacing `docker` by `docker.exe` if necessary.
   This will download prerequisite containers and install the necessary packages. <br />
   `docker build -t funnel_base docker/funnel_base`
2. (Re)build the individual containers by running <br />
   `docker-compose build`
3. Start the containers by running <br />
   `docker-compose up`

## Configuration

Configuration files are supplied in the `config` directory.
Data files (in csv format) should be placed in the `data` directory; sample files are present in the repository.
Keys for the secure averaging algorithm are supplied in the `keys` directory; this directory also contains instructions on key (re)generation.
