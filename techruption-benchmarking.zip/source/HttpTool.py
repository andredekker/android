import asyncio
from aiohttp import ClientSession
import pickle

# this code lifted from protocol_average

async def fetch(url, session, player):
    async with session.get(url) as response:
        assert response.status == 200, "Did not receive status OK (200)"
        data = await response.read()
        return data, player


async def fetch_shared_decryption(config):
    tasks = []

    # Fetch all responses within one Client session,
    # keep connection alive for all requests.
    async with ClientSession() as session:
        for party_i in range(int(config.number_of_parties)):
            url = "http://" + config.ip_addresses[party_i] + config.partial_decryption_filename
            task = asyncio.ensure_future(fetch(url, session, party_i))
            tasks.append(task)

        responses = await asyncio.gather(*tasks)

        data = [pickle.loads(response[0])[0] for response in responses]
        return data


async def fetch_public_ciphers(config):
    tasks = []
    print('Fetch shared ciphers')
    # Fetch all responses within one Client session,
    # keep connection alive for all requests.
    async with ClientSession() as session:
        for party_i in range(int(config.number_of_parties)):
            url = "http://" + config.ip_addresses[party_i] + config.shared_secret_filename
            task = asyncio.ensure_future(fetch(url, session, party_i))
            tasks.append(task)

        responses = await asyncio.gather(*tasks)

        data = [pickle.loads(r[0]) for r in responses]
        players_in_order = [r[1] for r in responses]
        return data, players_in_order