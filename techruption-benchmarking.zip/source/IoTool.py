import pickle
import fcntl
import time

# Read a file that might be unavailable
def read_file(filename):
    return read_file_timeout(filename, 15, 0.01)

def read_file_timeout(filename, timeout, waiting_time):
    start_time = time.time()
    timeout_check = True
    while timeout_check:
        try:
            f = open(filename, 'rb')
            data = pickle.load(f)
            f.close()
            return data
        except IOError as e:
            if time.time() - start_time > timeout:
                print('Time is over! Try again.')
                timeout_check = False
            time.sleep(waiting_time)
        except EOFError as e:
            time.sleep(waiting_time)

def write_file(target_file, data):
    '''
    Utility to write values to pickled files
    '''
    f = open(target_file, 'wb')
    fcntl.lockf(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    pickle.dump(data, f)
    fcntl.lockf(f, fcntl.LOCK_UN)
    f.close()