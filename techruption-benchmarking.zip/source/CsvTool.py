import csv

#################################################################
# CSV reader
#
# Imports configuration file and loads it as an object
def get_csv(filename):
    rows = []
    with open(filename) as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
                rows.append(row)
    print(rows[0])
    return rows

# Counts how often "colname" is true
def csv_count(csv, colname):
    count = 0;
    for entry in csv:
        if entry[colname] in ["true", "True", "TRUE", "1", 1, 1.0]:
            count += 1
    return count
